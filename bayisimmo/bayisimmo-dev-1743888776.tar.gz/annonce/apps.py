from django.apps import AppConfig


class AnnonceConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'annonce'
